import os
import base64
import requests
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

BOT_TOKEN = os.environ["BOT_TOKEN"]

@app.get("/")
def index():
    user_id = request.args.get("user_id", "")
    return render_template("index.html", user_id=user_id)

@app.post("/upload")
def upload():
    data = request.get_json(silent=True) or {}
    user_id = data.get("user_id")
    image = data.get("image")

    if not user_id or not image or "," not in image:
        return jsonify(error="Недостаточно данных"), 400

    try:
        image_bytes = base64.b64decode(image.split(",", 1)[1])
    except Exception:
        return jsonify(error="Некорректное изображение"), 400

    response = requests.post(
        f"https://api.telegram.org/bot{BOT_TOKEN}/sendPhoto",
        data={"chat_id": user_id},
        files={"photo": ("photo.jpg", image_bytes, "image/jpeg")},
        timeout=30,
    )

    if not response.ok:
        return jsonify(error="Telegram API не принял фотографию"), 502

    return jsonify(success=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
