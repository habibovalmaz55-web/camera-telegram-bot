import os
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

BOT_TOKEN = os.environ["BOT_TOKEN"]
WEB_URL = os.environ["WEB_URL"].rstrip("/")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    link = f"{WEB_URL}/?user_id={update.effective_user.id}"
    await update.message.reply_text(
        "Ссылка на страницу:\n\n"
        f"{link}\n\n"
        "Камера используется только с явного разрешения пользователя."
    )

app = Application.builder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))

if __name__ == "__main__":
    app.run_polling()
